# Member 3 Architecture

Member 1 -> Member 2 -> Member 3 -> Member 4 integration.

Member 3 consumes the exact Member 2 CSV and adds:
- FastAPI backend
- LangGraph orchestration
- Local lexical RAG
- Optional OpenAI LLM
- Compliance screening
- AI incident reports
- Timeline/MITRE/NIST APIs
- React dashboard

Member 3 does not recalculate Member 2 anomaly, classification, risk, severity, MITRE or NIST labels.
