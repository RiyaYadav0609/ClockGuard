# Notes
- NIST phase is derived in Member 1/2, not CAM-LDS ground truth.
- Compliance is not legal advice.
- OpenAI is optional. Without OPENAI_API_KEY the deterministic fallback report/chat works.
- Reports are generated on demand and saved under data/output.
