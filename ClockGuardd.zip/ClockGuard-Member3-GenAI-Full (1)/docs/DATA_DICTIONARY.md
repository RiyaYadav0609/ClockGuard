# Data dictionary

The input CSV is the real Member 2 output supplied for ClockGuard. It contains 6,713 rows and 27 columns. Core Member 3 fields are incident_id, timestamp, command, evidence, MITRE fields, NIST fields, anomaly fields, incident_type, risk_score, severity and risk_reason.
