from fastapi.testclient import TestClient
from src.api import app, data

client=TestClient(app)

def test_health():
    r=client.get('/health'); assert r.status_code==200; assert r.json()['module']=='Member 3'

def test_summary():
    r=client.get('/api/summary'); assert r.status_code==200; assert r.json()['rows']==len(data.df)

def test_incidents():
    r=client.get('/api/incidents?limit=5'); assert r.status_code==200; assert len(r.json())==5

def test_incident_and_views():
    iid=str(data.df.iloc[0]['incident_id'])
    assert client.get(f'/api/incidents/{iid}').status_code==200
    assert client.get(f'/api/timeline/{iid}').status_code==200
    assert client.get(f'/api/mitre/{iid}').status_code==200
    assert client.get(f'/api/nist/{iid}').status_code==200

def test_analyze():
    iid=str(data.df.iloc[0]['incident_id'])
    r=client.get(f'/api/analyze/{iid}'); assert r.status_code==200
    body=r.json(); assert 'report' in body and 'compliance' in body
