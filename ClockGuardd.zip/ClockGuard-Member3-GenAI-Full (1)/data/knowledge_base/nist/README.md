# NIST incident-response context
The supplied Member 1/2 records use NIST function/phase fields such as Detect and Detection & Analysis. These NIST labels are derived by ClockGuard response-state rules; the CAM-LDS source does not provide NIST ground-truth labels. Member 3 must preserve that distinction in explanations and reports.
