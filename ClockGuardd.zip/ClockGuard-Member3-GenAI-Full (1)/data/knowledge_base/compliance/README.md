# Compliance screening context
Compliance output is a conservative screening aid. The dataset does not provide jurisdiction, applicable law, contractual obligations, regulator, or legally validated notification deadlines. Therefore Member 3 must not invent a legal deadline or claim that a specific regulation is triggered solely from these fields. Human legal/compliance review is required.
