# MITRE ATT&CK context
ClockGuard receives MITRE technique, technique name and tactic labels from Member 1/Member 2. In this project, the CAM-LDS-derived MITRE labels are treated as dataset-grounded inputs. Member 3 explains and retrieves context; it does not remap the techniques.

Common examples in the supplied data include T1059 Command and Scripting Interpreter, T1595 Active Scanning, T1590.002 Gather Victim Network Information: DNS, T1547 Boot or Logon Autostart Execution, and T1069 Permission Groups Discovery.
