# ClockGuard — Final Magenta SOC Frontend

This frontend is a reference-matched enterprise SOC interface for the ClockGuard Microsoft Innovate project.

## Design direction
- Black / near-black SOC background
- Magenta / pink primary visual language
- Large readable typography and dense enterprise information hierarchy
- Separate purpose-built pages instead of putting every feature on Command Center
- Reference-style command center composition

## Connected pages
- Command Center
- Threat Landscape
- Incidents
- Investigation
- Attack Path
- MITRE ATT&CK Explorer
- NIST Incident Response
- Response Timeline
- Threat Analytics
- AI Investigation
- AI SOC Assistant
- Compliance Center
- Security Incident Reports
- Knowledge Base
- Settings

## Backend
The frontend expects Member 3 FastAPI on port 8003.

```powershell
python -m uvicorn src.api:app --host 127.0.0.1 --port 8003
```

Health check:
`http://127.0.0.1:8003/health`

## Frontend
```powershell
npm install
npm run dev
```

Open `http://localhost:5173`.

Vite proxies `/api` and `/health` to `http://127.0.0.1:8003`.

## Important data behaviour
- Incidents are de-duplicated by incident ID for the case-management view.
- Peak anomaly is shown only when Member 2 supplies anomaly scores.
- Risk remains the backend Member 2 value; the frontend does not silently replace it.
- Attack Path and Response Timeline use the selected incident's returned evidence rows.
- Threat Analytics uses actual summary/event intelligence rather than decorative placeholder charts.
- Threat Landscape is activity-based because the supplied CAM-LDS pipeline does not provide reliable geographic attribution; no attacker country is invented.
- NIST phase labels are presented as ClockGuard-derived response state, not CAM-LDS ground truth.
- Azure credentials remain in the backend `.env`; they are never placed in the frontend.
