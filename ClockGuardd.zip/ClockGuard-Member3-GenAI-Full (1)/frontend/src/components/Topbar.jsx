import { useEffect, useMemo, useState } from 'react';
import { Icon } from './Icons';


const SEVENTY_TWO_HOURS =
  72 * 60 * 60 * 1000;

const TWENTY_FOUR_HOURS =
  24 * 60 * 60 * 1000;


function getTimestamp(value) {

  if (!value) {
    return null;
  }

  const time =
    new Date(value).getTime();

  return Number.isNaN(time)
    ? null
    : time;
}


function formatRemaining(ms) {

  if (ms <= 0) {
    return '00:00:00';
  }

  const totalSeconds =
    Math.floor(ms / 1000);

  const hours =
    Math.floor(
      totalSeconds / 3600
    );

  const minutes =
    Math.floor(
      (totalSeconds % 3600) / 60
    );

  const seconds =
    totalSeconds % 60;

  return (
    `${String(hours).padStart(2, '0')}:` +
    `${String(minutes).padStart(2, '0')}:` +
    `${String(seconds).padStart(2, '0')}`
  );
}


export default function Topbar({
  title,
  incidents,
  selected,
  setSelected,
  onRefresh,
  loading,
  complianceResult,
  complianceLoading,
}) {

  const [now, setNow] =
    useState(Date.now());

  const [showNotification, setShowNotification] =
    useState(false);


  // =========================================================
  // FIND SELECTED INCIDENT
  // =========================================================

  const selectedIncident = useMemo(() => {

    return incidents.find(
      (item) =>
        item.incident_id === selected
    );

  }, [incidents, selected]);


  // =========================================================
  // LIVE CLOCK
  //
  // IMPORTANT:
  // This ONLY counts down toward the deadline supplied
  // by Compliance.
  //
  // It NEVER creates a new 72-hour deadline.
  // =========================================================

  useEffect(() => {

    const timer =
      setInterval(() => {

        setNow(Date.now());

      }, 1000);


    return () =>
      clearInterval(timer);

  }, []);


  // =========================================================
  // COMPLIANCE RESULT FROM APP
  // =========================================================

  const notificationTriggered =
    complianceResult?.notification_triggered === true;


  const deadline =
    notificationTriggered
      ? getTimestamp(
          complianceResult?.notification_deadline
        )
      : null;


  const hasClock =
    notificationTriggered &&
    deadline !== null;


  const remaining =
    hasClock
      ? deadline - now
      : null;


  const deadlineReached =
    hasClock &&
    remaining <= 0;


  const approachingDeadline =
    hasClock &&
    remaining > 0 &&
    remaining <= TWENTY_FOUR_HOURS;


  // =========================================================
  // NOTIFICATION
  //
  // Show notification whenever Compliance has an active
  // notification clock.
  // =========================================================

  const notificationActive =
    hasClock;


  const notificationText =
    deadlineReached
      ? 'GDPR 72-hour notification deadline reached.'
      : approachingDeadline
      ? 'Less than 24 hours remain on the 72-hour notification clock.'
      : '72-hour compliance clock is active.';


  // =========================================================
  // PROGRESS
  // =========================================================

  const progress =
    hasClock
      ? Math.max(
          0,
          Math.min(
            100,
            (remaining /
              SEVENTY_TWO_HOURS) *
              100
          )
        )
      : 0;


  return (

    <header className="topbar">


      {/* =====================================================
          BREADCRUMB
      ====================================================== */}

      <div className="crumb">

        <span>
          SECURITY OPERATIONS
        </span>

        <b>/</b>

        <strong>
          {title}
        </strong>

      </div>


      {/* =====================================================
          SEARCH
      ====================================================== */}

      <div className="search">

        <Icon
          name="search"
          size={16}
        />

        <input
          placeholder="Search incidents, IPs, techniques, assets…"
        />

        <kbd>
          ⌘ K
        </kbd>

      </div>


      {/* =====================================================
          TOP ACTIONS
      ====================================================== */}

      <div className="topactions">


        {/* REFRESH */}

        <button
          className="iconbtn"
          title="Refresh"
          onClick={onRefresh}
        >
          {loading
            ? '…'
            : '↻'}
        </button>


        {/* LIVE STATUS */}

        <span className="live">

          <i />

          LIVE

        </span>


        {/* INCIDENT SELECTOR */}

        <select
          value={selected}
          onChange={(e) => {

            setSelected(
              e.target.value
            );

            setShowNotification(
              false
            );

          }}
        >

          <option value="">
            Select incident
          </option>

          {incidents
            .slice(0, 100)
            .map((i) => (

              <option
                key={i.incident_id}
                value={i.incident_id}
              >
                {i.incident_id}
              </option>

            ))}

        </select>


        {/* =================================================
            REGULATORY NOTIFICATION
        ================================================== */}

        <div
          style={{
            position: 'relative',
            display: 'flex',
            alignItems: 'center',
          }}
        >

          <button
            className="iconbtn"
            title={
              complianceLoading
                ? 'Checking compliance status...'
                : hasClock
                ? notificationText
                : 'No active compliance notification'
            }
            onClick={() =>
              setShowNotification(
                (previous) =>
                  !previous
              )
            }
            style={{
              position: 'relative',
              fontSize: '18px',
            }}
          >

            🔔


            {/* NOTIFICATION DOT */}

            {notificationActive && (

              <span
                style={{
                  position: 'absolute',
                  top: '4px',
                  right: '4px',
                  width: '7px',
                  height: '7px',
                  borderRadius: '50%',

                  background:
                    deadlineReached
                      ? '#ff3b6b'
                      : approachingDeadline
                      ? '#ffb020'
                      : '#72e6b4',

                  boxShadow:
                    '0 0 8px rgba(255,59,107,.8)',
                }}
              />

            )}

          </button>


          {/* =================================================
              NOTIFICATION PANEL
          ================================================== */}

          {showNotification && (

            <div
              style={{
                position: 'absolute',
                top: '48px',
                right: '0',
                width: '340px',
                padding: '16px',
                borderRadius: '12px',
                background: '#0d0d14',
                border:
                  '1px solid rgba(255,255,255,.12)',
                boxShadow:
                  '0 15px 40px rgba(0,0,0,.45)',
                zIndex: 9999,
              }}
            >


              {/* HEADER */}

              <div
                style={{
                  fontSize: '11px',
                  letterSpacing: '1px',
                  opacity: 0.65,
                  marginBottom: '6px',
                }}
              >
                REGULATORY NOTIFICATION
              </div>


              <strong
                style={{
                  display: 'block',
                  marginBottom: '12px',
                  fontSize: '15px',
                }}
              >
                GDPR 72-Hour Compliance Clock
              </strong>


              {/* =================================================
                  NO ACTIVE CLOCK
              ================================================== */}

              {!hasClock && (

                <div
                  style={{
                    fontSize: '13px',
                    opacity: 0.7,
                    lineHeight: 1.5,
                  }}
                >

                  {complianceLoading
                    ? 'Checking compliance status...'
                    : selectedIncident
                    ? 'No active 72-hour compliance notification for this incident.'
                    : 'Select an incident to check its compliance status.'}

                </div>

              )}


              {/* =================================================
                  ACTIVE CLOCK
              ================================================== */}

              {hasClock && (

                <>


                  {/* COUNTDOWN */}

                  <div
                    style={{
                      fontSize: '28px',
                      fontWeight: 700,
                      letterSpacing: '1px',
                      marginBottom: '8px',
                      fontVariantNumeric:
                        'tabular-nums',
                    }}
                  >

                    {formatRemaining(
                      remaining
                    )}

                  </div>


                  {/* STATUS */}

                  <div
                    style={{
                      fontSize: '12px',
                      marginBottom: '12px',

                      color:
                        deadlineReached
                          ? '#ff3b6b'
                          : approachingDeadline
                          ? '#ffb020'
                          : '#72e6b4',
                    }}
                  >

                    {deadlineReached

                      ? '● NOTIFICATION DEADLINE REACHED'

                      : approachingDeadline

                      ? '● DEADLINE APPROACHING'

                      : '● COMPLIANCE CLOCK ACTIVE'

                    }

                  </div>


                  {/* PROGRESS */}

                  <div
                    style={{
                      height: '5px',
                      background:
                        'rgba(255,255,255,.08)',
                      borderRadius: '10px',
                      overflow: 'hidden',
                    }}
                  >

                    <div
                      style={{
                        width:
                          `${progress}%`,
                        height: '100%',

                        background:
                          deadlineReached
                            ? '#ff3b6b'
                            : approachingDeadline
                            ? '#ffb020'
                            : '#72e6b4',

                        transition:
                          'width 1s linear',
                      }}
                    />

                  </div>


                  {/* INCIDENT INFORMATION */}

                  <div
                    style={{
                      marginTop: '12px',
                      fontSize: '12px',
                      lineHeight: 1.5,
                      opacity: 0.7,
                    }}
                  >

                    Incident:{' '}

                    <b>
                      {selectedIncident?.incident_id ||
                        selected ||
                        '—'}
                    </b>

                    <br />

                    Awareness timestamp:{' '}

                    {selectedIncident?.timestamp ||
                      '—'}

                    <br />

                    Deadline:{' '}

                    <b>
                      {complianceResult?.notification_deadline
                        ? new Date(
                            complianceResult.notification_deadline
                          ).toLocaleString()
                        : '—'}
                    </b>

                  </div>


                  {/* =================================================
                      DEADLINE REACHED
                  ================================================== */}

                  {deadlineReached && (

                    <div
                      style={{
                        marginTop: '14px',
                        padding: '10px',
                        borderRadius: '8px',
                        background:
                          'rgba(255,59,107,.10)',
                        border:
                          '1px solid rgba(255,59,107,.25)',
                        color: '#ff6b91',
                        fontSize: '12px',
                        lineHeight: 1.5,
                      }}
                    >

                      <b>
                        GDPR 72-HOUR NOTIFICATION REQUIRED
                      </b>

                      <br />

                      Review the incident and initiate
                      the applicable regulatory
                      notification workflow.

                    </div>

                  )}


                  {/* =================================================
                      APPROACHING DEADLINE
                  ================================================== */}

                  {approachingDeadline && (

                    <div
                      style={{
                        marginTop: '14px',
                        padding: '10px',
                        borderRadius: '8px',
                        background:
                          'rgba(255,176,32,.10)',
                        border:
                          '1px solid rgba(255,176,32,.25)',
                        color: '#ffc45c',
                        fontSize: '12px',
                        lineHeight: 1.5,
                      }}
                    >

                      <b>
                        NOTIFICATION WINDOW APPROACHING
                      </b>

                      <br />

                      Less than 24 hours remain.

                    </div>

                  )}

                </>

              )}

            </div>

          )}

        </div>


        {/* AVATAR */}

        <div className="avatar">
          RY
        </div>

      </div>

    </header>
  );
}