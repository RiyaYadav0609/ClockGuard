import { Icon } from './Icons';

const groups = [
  [
    'COMMAND',
    [
      'overview',
      'threat',
      'incidents',
      'investigation',
      'attack',
    ],
  ],
  [
    'INTELLIGENCE',
    [
      'mitre',
      'nist',
      'timeline',
      'analytics',
      'knowledge',
    ],
  ],
  [
    'AI OPERATIONS',
    [
      'ai',
      'assistant',
      'compliance',
      'reports',
    ],
  ],
  [
    'SYSTEM',
    [
      'settings',
    ],
  ],
];

const meta = {
  overview: ['grid', 'Command Center'],
  threat: ['radar', 'Threat Landscape'],
  incidents: ['alert', 'Incidents'],
  investigation: ['target', 'Investigation'],
  attack: ['route', 'Attack Path'],
  mitre: ['shield', 'MITRE ATT&CK'],
  timeline: ['route', 'Response Timeline'],
  analytics: ['radar', 'Threat Analytics'],
  nist: ['shield', 'NIST Incident Response'],
  knowledge: ['doc', 'Knowledge Base'],
  ai: ['brain', 'AI Investigation'],
  assistant: ['brain', 'AI Assistant'],
  compliance: ['doc', 'Compliance'],
  reports: ['doc', 'Reports'],
  settings: ['settings', 'Settings'],
};

export default function Sidebar({
  page,
  setPage,
  health,
}) {
  return (
    <aside className="sidebar">

      <div className="brand">
        <div className="brandmark">
          C
        </div>

        <div>
          <strong>
            CLOCK<span>GUARD</span>
          </strong>

          <small>
            AI-POWERED SECURITY OPERATIONS
          </small>
        </div>
      </div>

      <div className="env">
        <i className={health ? 'ok' : ''}></i>

        {health
          ? 'SYSTEM OPERATIONAL'
          : 'CONNECTING TO BACKEND'}
      </div>

      {groups.map(([g, items]) => (
        <div
          className="navgroup"
          key={g}
        >
          <label>
            {g}
          </label>

          {items.map((k) => (
            <button
              className={
                page === k
                  ? 'active'
                  : ''
              }
              key={k}
              onClick={() =>
                setPage(k)
              }
            >
              <Icon
                name={meta[k][0]}
              />

              <span>
                {meta[k][1]}
              </span>
            </button>
          ))}
        </div>
      ))}

      <div className="sidebottom">

        <div className="statusrow">
          <span>API</span>

          <b
            className={
              health
                ? 'green'
                : ''
            }
          >
            {health
              ? 'ONLINE'
              : 'OFFLINE'}
          </b>
        </div>

        <div className="statusrow">
          <span>AI ENGINE</span>

          <b
            className={
              health
                ? 'green'
                : ''
            }
          >
            {health
              ? 'READY'
              : '—'}
          </b>
        </div>

        <div className="statusrow">
          <span>DATA PIPELINE</span>

          <b
            className={
              health
                ? 'green'
                : ''
            }
          >
            {health
              ? 'LIVE'
              : '—'}
          </b>
        </div>

      </div>

      <div className="version">
        CLOCKGUARD v2.0 · SOC PLATFORM
      </div>

    </aside>
  );
}