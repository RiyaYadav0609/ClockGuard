import React from 'react';

/* =========================================================
   PANEL
   ========================================================= */

export function Panel({
  title,
  eyebrow,
  action,
  children,
  className = ''
}) {
  return (
    <section className={`panel ${className}`}>
      <div className="panelhead">
        <div>
          {eyebrow && <small>{eyebrow}</small>}
          <h3>{title}</h3>
        </div>
        {action}
      </div>

      {children}
    </section>
  );
}


/* =========================================================
   STAT
   ========================================================= */

export function Stat({
  label,
  value,
  delta,
  kind = 'pink',
  spark = []
}) {
  return (
    <div className={`stat ${kind}`}>
      <div className="statlabel">
        <span>{label}</span>
        <i />
      </div>

      <strong>{value}</strong>

      <small>{delta}</small>

      {spark.length > 1 && (
        <svg
          className="spark"
          viewBox="0 0 100 32"
          preserveAspectRatio="none"
        >
          <polyline
            points={spark
              .map(
                (v, i) =>
                  `${i * (100 / (spark.length - 1))},${31 - v}`
              )
              .join(' ')}
            fill="none"
            stroke="currentColor"
            strokeWidth="2.4"
          />
        </svg>
      )}
    </div>
  );
}


/* =========================================================
   CLOCKGUARD TELEMETRY LINE CHART
   ========================================================= */

export function LineChart({
  series = [],
  series2 = [],
  series3 = []
}) {
  const all = [
    ...series,
    ...series2,
    ...series3
  ];

  const max = Math.max(...all, 1);

  const getPoints = (data) => {
    if (!data || data.length < 2) return '';

    return data
      .map((value, i) => {
        const x =
          i * (100 / (data.length - 1));

        const y =
          46 - (value / max) * 34;

        return `${x},${y}`;
      })
      .join(' ');
  };

  const eventPoints = getPoints(series);
  const incidentPoints = getPoints(series2);
  const anomalyPoints = getPoints(series3);

  return (
    <div className="chartbox telemetryChart">

      <svg
        viewBox="0 0 100 55"
        preserveAspectRatio="none"
        className="linechart"
      >

        <defs>

          {/* Soft event glow */}
          <linearGradient
            id="telemetryPinkFill"
            x1="0"
            y1="0"
            x2="0"
            y2="1"
          >
            <stop
              offset="0%"
              stopColor="#ff1fcb"
              stopOpacity=".14"
            />

            <stop
              offset="100%"
              stopColor="#ff1fcb"
              stopOpacity="0"
            />
          </linearGradient>


          {/* Subtle glow */}
          <filter
            id="telemetryGlow"
            x="-20%"
            y="-20%"
            width="140%"
            height="140%"
          >
            <feGaussianBlur
              stdDeviation="0.7"
              result="blur"
            />

            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

        </defs>


        {/* ================= GRID ================= */}

        <g
          className="telemetryGrid"
          fill="none"
          stroke="#29252c"
          strokeWidth=".35"
        >
          <path d="M0 12H100" />
          <path d="M0 25H100" />
          <path d="M0 38H100" />
          <path d="M0 50H100" />
        </g>


        {/* ================= VERTICAL GRID ================= */}

        <g
          fill="none"
          stroke="#201d24"
          strokeWidth=".25"
          opacity=".65"
        >
          <path d="M16.66 6V50" />
          <path d="M33.33 6V50" />
          <path d="M50 6V50" />
          <path d="M66.66 6V50" />
          <path d="M83.33 6V50" />
        </g>


        {/* ================= EVENTS AREA ================= */}

        {series.length > 1 && (
          <polygon
            points={`0,50 ${eventPoints} 100,50`}
            fill="url(#telemetryPinkFill)"
          />
        )}


        {/* ================= EVENTS ================= */}

        {series.length > 1 && (
          <polyline
            points={eventPoints}
            fill="none"
            stroke="#ff1fcb"
            strokeWidth="0.75"
            strokeLinecap="round"
            strokeLinejoin="round"
            filter="url(#telemetryGlow)"
          />
        )}


        {/* ================= INCIDENTS ================= */}

        {series2.length > 1 && (
          <polyline
            points={incidentPoints}
            fill="none"
            stroke="#ff70df"
            strokeWidth="0.62"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        )}


        {/* ================= ANOMALIES ================= */}

        {series3.length > 1 && (
          <polyline
            points={anomalyPoints}
            fill="none"
            stroke="#b983b1"
            strokeWidth="0.55"
            strokeLinecap="round"
            strokeLinejoin="round"
            opacity=".9"
          />
        )}

      </svg>

    </div>
  );
}


/* =========================================================
   DONUT
   ========================================================= */

export function Donut({ items = [] }) {
  const total =
    items.reduce((a, b) => a + b[1], 0) || 1;

  const colors = [
    '#ff1fcb',
    '#ff7a45',
    '#f6c744',
    '#22d3ee'
  ];

  let acc = 0;

  return (
    <div className="donutwrap">

      <div
        className="donut"
        style={{
          background: `conic-gradient(${items
            .map((x, i) => {
              const s =
                (acc / total) * 360;

              acc += x[1];

              const e =
                (acc / total) * 360;

              return `${colors[i % 4]} ${s}deg ${e}deg`;
            })
            .join(',')})`
        }}
      >
        <div>
          <b>{total.toLocaleString()}</b>
          <span>Total</span>
        </div>
      </div>


      <div className="legend">

        {items.map((x, i) => (
          <div key={x[0]}>

            <i
              style={{
                background:
                  colors[i % 4]
              }}
            />

            <span>{x[0]}</span>

            <b>
              {x[1]}
            </b>

          </div>
        ))}

      </div>

    </div>
  );
}


/* =========================================================
   ACTIVITY BARS
   ========================================================= */

export function ActivityBars({ items = [] }) {
  const max =
    Math.max(
      ...items.map(x => x[1]),
      1
    );

  return (
    <div className="barlist">

      {items.map(([name, val]) => (
        <div
          className="barrow"
          key={name}
        >

          <div>
            <span>{name}</span>
            <b>{val.toLocaleString()}</b>
          </div>

          <i>
            <em
              style={{
                width: `${Math.max(
                  4,
                  (val / max) * 100
                )}%`
              }}
            />
          </i>

        </div>
      ))}

    </div>
  );
}


/* =========================================================
   THREAT NETWORK
   ========================================================= */

export function ThreatNetwork({ items = [] }) {
  const data = items.slice(0, 8);

  return (
    <div className="threatnetwork">

      <svg
        viewBox="0 0 900 360"
        preserveAspectRatio="none"
      >

        {data.map(([name, val], i) => {

          const x =
            90 +
            (i % 4) * 230 +
            (i % 2) * 25;

          const y =
            70 +
            Math.floor(i / 4) * 190;

          return (
            <g key={name}>

              <line
                x1="450"
                y1="180"
                x2={x}
                y2={y}
                stroke="#7d276f"
                strokeWidth="1"
                opacity=".7"
                strokeDasharray="5 8"
              >
                <animate
                  attributeName="stroke-dashoffset"
                  from="0"
                  to="-26"
                  dur="1.7s"
                  repeatCount="indefinite"
                />
              </line>


              <circle
                cx={x}
                cy={y}
                r={Math.min(
                  38,
                  20 + val / 100
                )}
                fill="#0a1018"
                stroke={
                  i % 3 === 0
                    ? '#ff2bd6'
                    : i % 3 === 1
                    ? '#22d3ee'
                    : '#f6c744'
                }
                strokeWidth="2"
              />


              <text
                x={x}
                y={y - 4}
                textAnchor="middle"
                className="svgnum"
              >
                {val}
              </text>


              <text
                x={x}
                y={y + 13}
                textAnchor="middle"
                className="svgtxt"
              >
                {name.length > 20
                  ? name.slice(0, 18) + '…'
                  : name}
              </text>

            </g>
          );
        })}


        <circle
          cx="450"
          cy="180"
          r="54"
          fill="#100916"
          stroke="#ff2bd6"
          strokeWidth="3"
        />


        <text
          x="450"
          y="174"
          textAnchor="middle"
          className="svgcenter"
        >
          THREAT
        </text>


        <text
          x="450"
          y="191"
          textAnchor="middle"
          className="svgcenter"
        >
          INTELLIGENCE
        </text>

      </svg>

    </div>
  );
}


/* =========================================================
   ATTACK GRAPH
   ========================================================= */

export function AttackGraph({
  rows = [],
  incident
}) {
  const events =
    (rows || []).slice(0, 8);

  const fallback = [
    'Initial Access',
    'Execution',
    'Persistence',
    'Discovery',
    'Credential Access',
    'Lateral Movement'
  ];

  const labels = events.length
    ? events.map(
        r =>
          r.mitre_technique_id ||
          r.mitre_technique_name ||
          r.threat_class ||
          'Observed event'
      )
    : fallback;

  return (
    <div className="attackgraph">

      <div className="attacknodes">

        {labels.map((n, i) => (
          <React.Fragment
            key={`${n}-${i}`}
          >

            <div
              className={`attacknode ${
                i === labels.length - 1
                  ? 'last'
                  : ''
              }`}
            >

              <span>
                {String(i + 1).padStart(
                  2,
                  '0'
                )}
              </span>


              <b>{n}</b>


              <small>
                {events[i]?.mitre_tactic ||
                  events[i]?.threat_class ||
                  'Observed step'}
              </small>

            </div>


            {i < labels.length - 1 && (
              <i className="attackarrow">
                →
              </i>
            )}

          </React.Fragment>
        ))}

      </div>


      <div className="graphnote">
        {incident?.incident_id ||
          'Selected incident'}{' '}
        · {events.length || 0} observed
        steps reconstructed from backend
        evidence.
      </div>

    </div>
  );
}