// ClockGuard frontend API client.
// In development, Vite proxies /api and /health to the Member 3 FastAPI server
// on http://127.0.0.1:8003. Using relative URLs avoids browser CORS/localhost issues.
const BASE = (import.meta.env.VITE_API_BASE || '').replace(/\/$/, '');

async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(`${BASE}${path}`, {
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {}),
      },
      ...options,
    });
  } catch (error) {
    throw new Error(
      'Cannot reach ClockGuard Member 3 API. Start FastAPI on http://127.0.0.1:8003 and keep that terminal running.'
    );
  }

  if (!response.ok) {
    let body = '';
    try { body = await response.text(); } catch {}
    throw new Error(
      `${response.status} ${response.statusText}${body ? ` — ${body.slice(0, 180)}` : ''}`
    );
  }

  return response.status === 204 ? null : response.json();
}

export const api = {
  base: BASE || '/ (Vite proxy → 127.0.0.1:8003)',
  health: () => request('/health'),
  summary: () => request('/api/summary'),
  incidents: (params = {}) => request(`/api/incidents?${new URLSearchParams(params)}`),
  incident: (id) => request(`/api/incidents/${encodeURIComponent(id)}`),
  analyze: (id) => request(`/api/analyze/${encodeURIComponent(id)}`),
  timeline: (id) => request(`/api/timeline/${encodeURIComponent(id)}`),
  mitre: (id) => request(`/api/mitre/${encodeURIComponent(id)}`),
  nist: (id) => request(`/api/nist/${encodeURIComponent(id)}`),
  compliance: (id) => request(`/api/compliance/${encodeURIComponent(id)}`, { method: 'POST' }),
  report: (id) => request(`/api/report/${encodeURIComponent(id)}`, { method: 'POST' }),
  chat: (id, question) => request(`/api/chat/${encodeURIComponent(id)}`, {
    method: 'POST',
    body: JSON.stringify({ question }),
  }),
  analytics: () => request('/api/analytics').catch(() => null),
};

export function normalizeList(v) {
  return Array.isArray(v) ? v : (v?.incidents || v?.data || v?.rows || v?.timeline || []);
}
