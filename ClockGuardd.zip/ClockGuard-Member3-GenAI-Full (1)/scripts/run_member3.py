import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src.config import API_HOST, API_PORT
import uvicorn
uvicorn.run("src.api:app", host=API_HOST, port=API_PORT, reload=False)
